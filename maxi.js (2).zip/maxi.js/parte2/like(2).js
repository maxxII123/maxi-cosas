var cambiolike = document.querySelector("#lokes");
var cambiolakes = document.querySelector("#lakes");
var cambiolukes = document.querySelector("#lukes");

function cambiarlike(id) {
    cambiolike.innerHTML = parseInt(cambiolike.innerHTML) + 1;
}

function cambiarlakess(id){
    cambiolakes.innerHTML = parseInt(cambiolakes.innerHTML)+1;
}

function cambiarlukess(id){
    cambiolukes.innerHTML= parseInt(cambiolukes.innerHTML)+1;
}