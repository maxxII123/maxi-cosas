var cambiolike = document.querySelector("#lokes");

function cambiarlike(id) {
    cambiolike.innerHTML = parseInt(cambiolike.innerHTML) + 1;

}


